
#cc bfgs_example_3.c -o bfgs_example_3 -I /usr/local/include -L /usr/local/lib -lgsl -lgslcblas -lm
cc deconvolution-BFGS.c -o deconvolution-BFGS -I /usr/local/include -L /usr/local/lib -lgsl -lgslcblas -lm
